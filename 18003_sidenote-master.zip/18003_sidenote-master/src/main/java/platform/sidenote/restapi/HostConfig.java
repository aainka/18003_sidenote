package platform.sidenote.restapi;

public class HostConfig {

	public static boolean isLinux() {
		return true;
	}

	public static boolean isWebMode() {
		return true;
	}

}
