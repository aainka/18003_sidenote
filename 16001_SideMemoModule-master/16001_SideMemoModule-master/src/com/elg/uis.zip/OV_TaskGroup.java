package com.elg.uis;

import java.util.LinkedList;

public class OV_TaskGroup extends LinkedList<OV_Task> {
	public String name;
	public String toString() {
		return name;
	}
}
