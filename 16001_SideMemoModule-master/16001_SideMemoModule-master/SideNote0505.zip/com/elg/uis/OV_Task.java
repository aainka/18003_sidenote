package com.elg.uis;

import java.util.Date;

import javax.swing.tree.DefaultMutableTreeNode;

public class OV_Task {
	int id;
	String subject;
	Date created;
	Date started;
	Date closed;
	String requestedby;
	String assigned;
	int parent_id;
	public String category;
	public String priority;
	public String note;
	
	public String toString() {
		return subject;
	}
}
