package com.elg.uis;

import java.util.LinkedList;
import java.util.List;

public class OV_Task_Dao {
	
	private String filename = "";
	private List<OV_Task>list = new LinkedList<OV_Task>();
	private ObjectMapper = new ObjectMapper

	private void save() {
		OV_Task r = new OV_Task();
		r.subject = "test-123";
		list.add(r);
	}
	
	private void load() {
		
	}
}
