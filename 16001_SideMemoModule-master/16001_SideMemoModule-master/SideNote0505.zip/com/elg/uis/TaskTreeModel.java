package com.elg.uis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

public class TaskTreeModel extends DataTreeModel {

	private List<OV_Task> list = null;
	private File file = new File("C:/tmp/aaa.gson");
	int seqNumber = 1;

	public TaskTreeModel() {
		loadNodes();
	}

	@Override
	public void saveNodes() {
		list = new LinkedList<OV_Task>();
		buildSaveList((DefaultMutableTreeNode) this.getRoot());
		System.out.println("SAVE ::: count=" + list.size());

		Type listType = new TypeToken<List<OV_Task>>() {
		}.getType();
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			OutputStream outputStream = new FileOutputStream(file);
			BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
			gson.toJson(list, listType, bufferedWriter);
			bufferedWriter.close();
		} catch (JsonIOException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void buildSaveList(DefaultMutableTreeNode node) {
		if (node.getChildCount() == 0) {
			return;
		}
		DefaultMutableTreeNode child = (DefaultMutableTreeNode) node.getFirstChild();
		while (child != null) {
			list.add((OV_Task) child.getUserObject());
			// todo add child index;
			buildSaveList(child);
			child = child.getNextSibling();
		}
	}

	@Override
	public void loadNodes() {
		seqNumber = 1;
		HashMap<Integer, DefaultMutableTreeNode> map = new HashMap<Integer, DefaultMutableTreeNode>();
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Type listType = new TypeToken<List<OV_Task>>() {
			}.getType();

			FileInputStream fis = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			JsonReader reader = new JsonReader(br);

			List<OV_Task> list = gson.fromJson(reader, listType);
			for (OV_Task task : list) {
				DefaultMutableTreeNode node = new DefaultMutableTreeNode();
				node.setUserObject(task);

				DefaultMutableTreeNode pNode = null;
				if (task.parent_id != 0) {
					pNode = map.get(task.parent_id);
				}
				if (pNode == null) {
					root.add(node);
				} else {
					pNode.add(node);
				}
				if (task.id != 0) {
					map.put(task.id, node);
				}
				if (task.id >= seqNumber) {
					seqNumber = task.id + 1;
				}
			}
			for (OV_Task task : list) {
				if (task.id == 0) {
					task.id = seqNumber++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// List<String> target2 = gson.fromJson(json, listType);

		// System.out.println("Count=" + list.size());
		// String aa = gson.toJson(list, listType);
		// System.out.println(aa);

	}

	@Override
	public DefaultMutableTreeNode createNode(DefaultMutableTreeNode parent, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

}
