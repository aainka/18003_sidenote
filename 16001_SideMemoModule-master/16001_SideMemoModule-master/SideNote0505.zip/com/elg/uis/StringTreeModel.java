package com.elg.uis;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.DefaultMutableTreeNode;

@SuppressWarnings("serial")
public class StringTreeModel extends DataTreeModel {

	public StringTreeModel() {
		loadNodes();
	}

	@Override
	public void valueChanged(TreeSelectionEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void saveNodes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void loadNodes() {
		DefaultMutableTreeNode aaaa = new DefaultMutableTreeNode("aaaa");
		aaaa.add(new DefaultMutableTreeNode("xxxx"));
		root.add(aaaa);
		root.add(new DefaultMutableTreeNode("dddd"));
		root.add(new DefaultMutableTreeNode("cccc"));
	}


	@Override
	public DefaultMutableTreeNode createNode(DefaultMutableTreeNode parent, Object value) {
		DefaultMutableTreeNode newChild = new DefaultMutableTreeNode(value);
		insertNodeInto(newChild, parent, parent.getChildCount());
		return newChild;
	}
}
